package com.mycompany.grupo_5_pfa1;

/**
 * Clase ColaPacientes.
 * Hereda de ColaBase para manejar pacientes.
 * @author Grupo 5
 */

public class ColaPacientes extends ColaBase { // Inicio de la clase hija ColaPacientes.

    /**
     * Constructor vacío de ColaPacientes.
     * @author Grupo 5Diego
     */
    
    public ColaPacientes() { // Inicio del constructor.
        super(); // Llama al constructor de la clase padre ColaBase.
    } 
} 