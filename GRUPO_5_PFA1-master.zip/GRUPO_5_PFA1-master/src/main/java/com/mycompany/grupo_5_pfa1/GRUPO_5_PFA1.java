/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.grupo_5_pfa1;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.swing.JOptionPane;

/**
 * @author Grupo 5
 */

public class GRUPO_5_PFA1 { 

    /**
     * Método principal del programa.
     * @author Grupo 5
     * @param args Argumentos del programa.
     */

    public static void main(String[] args) {

        // Mensaje de bienvenida en consola.
        System.out.println("¡Bienvenido al sistema del Hospital Su Salud!");

        // Creación de estructuras de datos.
        ColaPacientes colaRegular      = new ColaPacientes();
        ColaPacientes colaPreferencial = new ColaPacientes();
        PilaQuejas    pilaQuejas       = new PilaQuejas();
        GestorAtencion gestor          = new GestorAtencion(colaPreferencial, colaRegular);

        // Opciones del menú principal según enunciado.
        String[] opcionesMenu = {
            "1. Gestionar Llegada de Pacientes",
            "2. Ayuda",
            "3. Salir"
        };

        boolean ejecutando = true;
        while (ejecutando) {
            int opcion = JOptionPane.showOptionDialog(
                null,
                "¡Bienvenido al sistema del Hospital Su Salud!\nSeleccione una opción:",
                "Menú Principal",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.PLAIN_MESSAGE,
                null,
                opcionesMenu,
                opcionesMenu[0]
            );

            switch (opcion) {
                case 0 -> mostrarSubmenu(gestor, colaRegular, colaPreferencial, pilaQuejas);
                case 1 -> mostrarAyuda();
                default -> {
                    // case 2 (Salir) o cerró la ventana con X
                    ejecutando = false;
                    JOptionPane.showMessageDialog(
                        null,
                        "Gracias por usar el sistema. ¡Hasta luego!",
                        "Salir",
                        JOptionPane.INFORMATION_MESSAGE
                    );
                }
            }
        }
    }

    /**
     * Muestra el submenú de Gestionar Llegada de Pacientes con sus 6 opciones.
     * @author Grupo 5
     * @param gestor           GestorAtencion activo.
     * @param colaRegular      Cola de pacientes regulares.
     * @param colaPreferencial Cola de pacientes preferenciales.
     * @param pilaQuejas       Pila de quejas del sistema.
     */
    private static void mostrarSubmenu(
            GestorAtencion gestor,
            ColaPacientes colaRegular,
            ColaPacientes colaPreferencial,
            PilaQuejas pilaQuejas) {

        // Opciones del submenú según enunciado (orden exacto).
        String[] opciones = {
            "1. Seleccionar Ficha",
            "2. Atender Paciente",
            "3. Abandonar Cola de Pacientes",
            "4. Mostrar Fichas Pendientes",
            "5. Mostrar Quejas Recibidas",
            "6. Regresar"
        };

        boolean enSubmenu = true;
        while (enSubmenu) {
            int opcion = JOptionPane.showOptionDialog(
                null,
                "Gestionar Llegada de Pacientes\nSeleccione una opción:",
                "Submenú — Hospital Su Salud",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.PLAIN_MESSAGE,
                null,
                opciones,
                opciones[0]
            );

            switch (opcion) {
                case 0 -> gestor.seleccionarFicha();                                 
                case 1 -> gestor.atenderPaciente();                                    
                case 2 -> pilaQuejas.abandonarColaInteractivo(colaRegular, colaPreferencial);
                case 3 -> mostrarFichasPendientes(colaRegular, colaPreferencial);      
                case 4 -> pilaQuejas.mostrarPila();                                    
                default -> enSubmenu = false;                                          
            }
        }
    }

    /**
     * Muestra en pantalla las fichas pendientes de ambas colas con su distintivo.
     * Preferenciales con distintivo [PREFERENCIAL - NARANJA], regulares con [REGULAR - VERDE].
     * @author Grupo 5
     * @param colaRegular      Cola de pacientes regulares.
     * @param colaPreferencial Cola de pacientes preferenciales.
     */
    private static void mostrarFichasPendientes(
            ColaPacientes colaRegular,
            ColaPacientes colaPreferencial) {

        // Imprime en consola con distintivos.
        System.out.println("\n--- Fichas Pendientes ---");
        colaPreferencial.mostrarCola("[PREFERENCIAL - NARANJA]");
        colaRegular.mostrarCola("[REGULAR - VERDE]");

        // También muestra en ventana JOptionPane para consistencia visual.
        StringBuilder sb = new StringBuilder();
        sb.append("=== [PREFERENCIAL - NARANJA] ===\n");
        sb.append(obtenerTextoCola(colaPreferencial));
        sb.append("\n=== [REGULAR - VERDE] ===\n");
        sb.append(obtenerTextoCola(colaRegular));

        JOptionPane.showMessageDialog(
            null,
            sb.toString(),
            "Fichas Pendientes",
            JOptionPane.INFORMATION_MESSAGE
        );
    }

    /**
     * Genera el texto con la información de todos los pacientes de una cola.
     * Accede a frente (protected en ColaBase) porque están en el mismo paquete.
     * @author Grupo 5
     * @param cola Cola que se desea listar.
     * @return String con los datos de cada paciente, o mensaje de cola vacía.
     */
    private static String obtenerTextoCola(ColaPacientes cola) {
        if (cola.esVacia()) {
            return "  No hay fichas pendientes.\n";
        }
        StringBuilder sb = new StringBuilder();
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        NodoPaciente aux = cola.frente; // frente es protected en ColaBase → accesible en mismo paquete.
        while (aux != null) {
            Paciente p = aux.getPaciente();
            sb.append("  Ficha: ").append(p.getFicha())
              .append(" | Cédula: ").append(p.getCedula())
              .append(" | Nombre: ").append(p.getNombre())
              .append(" | Llegada: ").append(sdf.format(p.getFechaLlegada()))
              .append("\n");
            aux = aux.getSiguiente();
        }
        return sb.toString();
    }

    /**
     * Muestra la pantalla de Ayuda con versión y desarrolladores.
     * @author Grupo 5
     */
    private static void mostrarAyuda() {
        String mensaje =
            "=== AYUDA — Sistema Hospital Su Salud ===\n\n" +
            "Versión: Avance 1 V 1.0.1\n\n" +
            "Desarrollado por Grupo 5:\n" +
            "  • [Camila Cabrera Camacho]\n" +
            "  • [Diego Armando Jimenez]\n" +
            "  • [Ismael Sanbria Moya]\n\n" +
            "  • [Israel Apuy Martinez]\n\n" +
            "Opciones disponibles en Gestionar Llegada de Pacientes:\n" +
            "  1. Seleccionar Ficha         — Registra un paciente (Regular o Preferencial)\n" +
            "  2. Atender Paciente          — Atiende según regla 2 preferenciales : 1 regular\n" +
            "  3. Abandonar Cola            — Retira una ficha y registra la queja\n" +
            "  4. Mostrar Fichas Pendientes — Lista ambas colas con distintivo de color\n" +
            "  5. Mostrar Quejas Recibidas  — Lista todas las quejas registradas\n" +
            "  6. Regresar                 — Vuelve al menú principal";

        JOptionPane.showMessageDialog(
            null,
            mensaje,
            "Ayuda",
            JOptionPane.INFORMATION_MESSAGE
        );
    }
}
 